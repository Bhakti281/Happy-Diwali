# Happy Diwali — The Festival of a Thousand Lights

An immersive, cinematic single-file Diwali experience: a staged opening sequence, a living diya,
canvas fireworks, a courtyard of seven lamps you light yourself, a personalised wish, and an
animated greeting card.

## Entry path

- `index.html` — the entire experience (HTML + CSS + vanilla JS in one file, no build step).

Open it directly in a browser (works from the local filesystem, no server or backend required).

## Experience structure

| Stage | What happens |
|---|---|
| Cinematic intro | Near-black screen → golden spark → flame → warm light bloom → self-drawing mandala → masked title reveal → *Enter the Experience* |
| Hero | Gold-gradient "Happy Diwali", ornate SVG diya with flickering layered flame, breathing halo, orbiting dashed rings, parallax on scroll |
| Chapter 1 — The Festival of Lights | Narrative columns plus three glass "essence" cards |
| Chapter 2 — Light up the courtyard | Seven interactive diyas; each lights with a flame, halo, burst and chime. Progress bar, message line, *Light them all* / *Gather the flames* |
| Chapter 3 — A Special Wish | Word-by-word cinematic reveal with gold italics |
| Chapter 4 — The Finale | Automatic volley on scroll-in, *Launch the grand finale* (rockets + confetti) |
| Surprise card | Ornamental modal with drifting petals, fireworks and confetti on open |

## Interaction inventory

- Click/tap anywhere outside UI → firework at that exact point (rocket ascent solved to hit the target height).
- Automatic ambient fireworks every ~5s; denser, capped on touch devices.
- Hero diya click → triple burst + confetti + bell chime.
- Courtyard diyas, light-all, reset.
- Mouse-responsive golden dust, cursor spotlight, bokeh floats, aurora drift.
- Scroll progress hairline, scroll-triggered reveals, sticky story column, diya parallax.
- Keyboard: `Esc` closes the card / menu; typing **diwali** triggers a hidden celebration.

## Music

A **generative instrumental** built with the Web Audio API — no audio files, no copyrighted
recordings, no external requests:

- Flute line, santoor arpeggios, sitar punctuation, soft tabla groove, festival bells
- Sustained tonic drone bed
- Procedurally generated convolution reverb and master compression

Controls: nav toggle (with animated EQ bars and playing/paused status), hover volume slider,
footer toggle. Playback starts only after a real user gesture; if Web Audio is unavailable the
controls degrade to an "Audio N/A" state instead of erroring.

## Accessibility

- `prefers-reduced-motion` shortens the intro, disables ambient/auto fireworks, confetti, bokeh and
  parallax, and forces all reveal states visible.
- Semantic landmarks, labelled buttons, `aria-pressed` on diyas and music, live regions for state
  announcements, focus restore on modal close, visible focus rings, `<noscript>` fallback.

## Verified

Checked in a headless browser at 1280×800 and 390×844: clean console, clean layout, intro sequence
completes, hero/sections render, all seven diyas light with aligned flames, surprise card opens.

Bug fixed during verification: the intro's state class `spark` collided with the `.spark` element
rule, which shrank the whole overlay to 1×1 and hid the opening sequence.

## Notes / next steps

- Fonts load from Google Fonts; the stack falls back to serif/system fonts offline.
- Fireworks render on a fixed full-viewport canvas with additive blending and motion trails.
- Possible extensions: shareable wish URLs, per-visitor name personalisation, WebGL sparkles.
